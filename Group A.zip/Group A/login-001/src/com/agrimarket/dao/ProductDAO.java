/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.agrimarket.dao;

/**
 *
 * @author joshua
 */
import com.raven.model.Product;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.raven.model.ModelUser;

public class ProductDAO {
    private Connection connection;

    public ProductDAO(Connection connection) {
        this.connection = connection;
    }
    
    public List<Product> searchProducts(String keyword, String category, double minPrice, double maxPrice) throws SQLException {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE " +
                     "(name LIKE ? OR description LIKE ?) " +
                     "AND (? = '' OR category = ?) " +
                     "AND (price BETWEEN ? AND ?)";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, "%" + keyword + "%");
            stmt.setString(2, "%" + keyword + "%");
            stmt.setString(3, category);
            stmt.setString(4, category);
            stmt.setDouble(5, minPrice);
            stmt.setDouble(6, maxPrice);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product(
                        rs.getInt("productID"),
                        rs.getString("name"),
                        rs.getString("category"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantity")
                    );
                    products.add(product);
                }
            }
        }
        return products;
    }
    
     public void addProduct(Product product) throws SQLException {
        String query = "INSERT INTO Products (name, category, description, price, quantity) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, product.getName());
            statement.setString(2, product.getCategory());
            statement.setString(3, product.getDescription());
            statement.setDouble(4, product.getPrice());
            statement.setInt(5, product.getQuantity());
            statement.executeUpdate();
        }
    }
     
    public Product getProductById(int productID) throws SQLException {
        String query = "SELECT * FROM Products WHERE productID = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, productID);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new Product(
                        resultSet.getInt("productID"),
                        resultSet.getString("name"),
                        resultSet.getString("category"),
                        resultSet.getString("description"),
                        resultSet.getDouble("price"),
                        resultSet.getInt("quantity")
                );
            }
        }
        return null;
    }

    public void updateProduct(Product product) throws SQLException {
        String query = "UPDATE Products SET name = ?, category = ?, description = ?, price = ?, quantity = ? WHERE productID = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, product.getName());
            statement.setString(2, product.getCategory());
            statement.setString(3, product.getDescription());
            statement.setDouble(4, product.getPrice());
            statement.setInt(5, product.getQuantity());
            statement.setInt(6, product.getProductID());
            statement.executeUpdate();
        }
    }

    public void deleteProduct(int productID) throws SQLException {
        String query = "DELETE FROM Products WHERE productID = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, productID);
            statement.executeUpdate();
        }
    }

    public List<Product> getAllProducts() throws SQLException {
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM Products";
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                products.add(new Product(
                        resultSet.getInt("productID"),
                        resultSet.getString("name"),
                        resultSet.getString("category"),
                        resultSet.getString("description"),
                        resultSet.getDouble("price"),
                        resultSet.getInt("quantity")
                ));
            }
        }
        return products;
    }
}


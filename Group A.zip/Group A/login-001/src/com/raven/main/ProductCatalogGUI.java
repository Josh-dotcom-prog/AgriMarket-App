package com.raven.main;

import com.agrimarket.dao.ProductDAO;
import com.raven.model.Product;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class ProductCatalogGUI extends JFrame {
    private ProductDAO productDAO;
    private JTextArea outputArea;
    private JTextField idField, nameField, categoryField, descriptionField, priceField, quantityField;

    public ProductCatalogGUI() {
        super("Product Catalog");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        try {
            Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/AgriMarketDB", "JoshCodes", "SysAdmin@21");
            productDAO = new ProductDAO(connection);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        inputPanel.add(new JLabel("ProductID:"));
        idField = new JTextField();
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Product Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Category:"));
        categoryField = new JTextField();
        inputPanel.add(categoryField);
        inputPanel.add(new JLabel("Description:"));
        descriptionField = new JTextField();
        inputPanel.add(descriptionField);
        inputPanel.add(new JLabel("Price:"));
        priceField = new JTextField();
        inputPanel.add(priceField);
        inputPanel.add(new JLabel("Quantity:"));
        quantityField = new JTextField();
        inputPanel.add(quantityField);

        add(inputPanel, BorderLayout.NORTH);

        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchPanel.add(new JLabel("Search:"));
        JTextField searchField = new JTextField(20);
        searchPanel.add(searchField);
        searchPanel.add(new JLabel("Category:"));
        JComboBox<String> categoryComboBox = new JComboBox<>(new String[]{"", "Fruits", "Vegetables", "Grains", "Dairy"});
        searchPanel.add(categoryComboBox);
        searchPanel.add(new JLabel("Min Price:"));
        JTextField minPriceField = new JTextField(5);
        searchPanel.add(minPriceField);
        searchPanel.add(new JLabel("Max Price:"));
        JTextField maxPriceField = new JTextField(5);
        searchPanel.add(maxPriceField);
        JButton searchButton = new JButton("Search");
        searchPanel.add(searchButton);

        add(searchPanel, BorderLayout.CENTER);
        
        // Button Panel
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Product");
        JButton viewButton = new JButton("View");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");
        JButton listButton = new JButton("List All");

        buttonPanel.add(addButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(listButton);

        add(buttonPanel, BorderLayout.CENTER);

        // Output Area
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        add(scrollPane, BorderLayout.SOUTH);

        // Action Listeners
        addButton.addActionListener(e -> addProduct());
        viewButton.addActionListener(e -> viewProduct());
        updateButton.addActionListener(e -> updateProduct());
        deleteButton.addActionListener(e -> deleteProduct());
        listButton.addActionListener(e -> listAllProducts());
        searchButton.addActionListener(e -> searchProducts());
    }

    private void addProduct() {
        try {
            String name = nameField.getText();
            String category = categoryField.getText();
            String description = descriptionField.getText();
            double price = Double.parseDouble(priceField.getText());
            int quantity = Integer.parseInt(quantityField.getText());

            Product product = new Product(0, name, category, description, price, quantity);
            productDAO.addProduct(product);
            outputArea.setText("Product added successfully.");
        } catch (SQLException | NumberFormatException ex) {
            outputArea.setText("Error: " + ex.getMessage());
        }
    }

    private void viewProduct() {
        try {
            int id = Integer.parseInt(idField.getText());
            Product product = productDAO.getProductById(id);
            if (product != null) {
                outputArea.setText("Product Details:\n" +
                        "ID: " + product.getProductID() + "\n" +
                        "Name: " + product.getName() + "\n" +
                        "Category: " + product.getCategory() + "\n" +
                        "Description: " + product.getDescription() + "\n" +
                        "Price: " + product.getPrice() + "\n" +
                        "Quantity: " + product.getQuantity());
            } else {
                outputArea.setText("Product not found.");
            }
        } catch (SQLException | NumberFormatException ex) {
            outputArea.setText("Error: " + ex.getMessage());
        }
    }

    private void updateProduct() {
        try {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String category = categoryField.getText();
            String description = descriptionField.getText();
            double price = Double.parseDouble(priceField.getText());
            int quantity = Integer.parseInt(quantityField.getText());

            Product product = new Product(id, name, category, description, price, quantity);
            productDAO.updateProduct(product);
            outputArea.setText("Product updated successfully.");
        } catch (SQLException | NumberFormatException ex) {
            outputArea.setText("Error: " + ex.getMessage());
        }
    }

    private void deleteProduct() {
        try {
            int id = Integer.parseInt(idField.getText());
            productDAO.deleteProduct(id);
            outputArea.setText("Product deleted successfully.");
        } catch (SQLException | NumberFormatException ex) {
            outputArea.setText("Error: " + ex.getMessage());
        }
    }

    private void listAllProducts() {
        try {
            List<Product> products = productDAO.getAllProducts();
            StringBuilder sb = new StringBuilder("Product List:\n");
            for (Product product : products) {
                sb.append(product.getProductID()).append(": ")
                  .append(product.getName()).append(" (")
                  .append(product.getCategory()).append(") - ")
                  .append(product.getPrice()).append("\n");
            }
            outputArea.setText(sb.toString());
        } catch (SQLException ex) {
            outputArea.setText("Error: " + ex.getMessage());
        }
    }


//     private void searchProducts() {
//    try {
//        String keyword = searchField.getText();
//        String category;
//        category = (String) categoryComboBox.getSelectedItem();
//        double minPrice;
//        minPrice = minPriceField.getText().isEmpty() ? 0 : Double.parseDouble((String) minPriceField.getText());
//        double maxPrice;
//        maxPrice = maxPriceField.getText().isEmpty() ? Double.MAX_VALUE : Double.parseDouble((String) maxPriceField.getText());
//
//        List<Product> products = productDAO.searchProducts(keyword, category, minPrice, maxPrice);
//        
//        StringBuilder sb = new StringBuilder("Search Results:\n");
//        for (Product product : products) {
//            sb.append(product.getProductID()).append(": ")
//              .append(product.getName()).append(" (")
//              .append(product.getCategory()).append(") - ")
//              .append(product.getPrice()).append("\n");
//        }
//        outputArea.setText(sb.toString());
//    } catch (SQLException | NumberFormatException ex) {
//        outputArea.setText("Error: " + ex.getMessage());
//    }
//}
     
     public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductCatalogGUI().setVisible(true));
    }

    private void searchProducts() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}